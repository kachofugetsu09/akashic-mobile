import{c as r,s as e}from"./flowDiagram-23GEKE2U-zEE6lyBF.js";import{_ as a}from"./mermaid-GHXKKRXX-Drvhvc_g.js";import"./chunk-5VM5RSS4-B31TiZPD.js";import"./chunk-XXDRQBXY-BfWq9XVU.js";import"./chunk-VR4S4FIN-BqzcxbY-.js";import"./chunk-32BRIVSS-D9_aWW2n.js";import"./channel-fRSBugy1.js";import"./mobile-ClYux6CV.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
