import{c as r,s as e}from"./flowDiagram-HODETNUW-D6_HHEZX.js";import{_ as a}from"./mermaid.core-BZGcgD2v.js";import"./chunk-5VM5RSS4-DBuDmklC.js";import"./chunk-XXDRQBXY-D8RrS2mt.js";import"./chunk-POPQ4Y6H-qEOG59RG.js";import"./chunk-F27PBJKO-Cxx-lWcj.js";import"./channel-CQZJHXpv.js";import"./mobile-De-E3SqF.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
