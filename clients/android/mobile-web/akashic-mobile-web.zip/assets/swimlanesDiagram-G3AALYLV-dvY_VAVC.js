import{c as r,s as e}from"./flowDiagram-23GEKE2U-L0vqXp1Y.js";import{_ as a}from"./index-Do6lY4jL.js";import"./chunk-5VM5RSS4-BSeLAGF_.js";import"./chunk-XXDRQBXY-BpJpVF0k.js";import"./chunk-VR4S4FIN-Brgft3IB.js";import"./chunk-32BRIVSS-9p9ekRgD.js";import"./channel-DoVpA00v.js";import"./mobile-D077kq-L.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
