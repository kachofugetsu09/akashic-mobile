import{U as a,C as n}from"./index-L9v9i1CL.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
