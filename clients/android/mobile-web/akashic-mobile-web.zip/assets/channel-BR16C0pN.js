import{U as a,C as n}from"./index-DOAhbcUm.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
