import{c as r,s as e}from"./flowDiagram-23GEKE2U-Cr6S-xwB.js";import{_ as a}from"./mermaid-GHXKKRXX-ranPcHgh.js";import"./chunk-5VM5RSS4-BUFeEVMk.js";import"./chunk-XXDRQBXY-DHbX5oF-.js";import"./chunk-VR4S4FIN-DpuIuE3K.js";import"./chunk-32BRIVSS-jJmV1vbW.js";import"./channel-Xbv6GV1U.js";import"./mobile-EcbayZep.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
