import{U as a,C as n}from"./mermaid-GHXKKRXX-_q0sfIMg.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
