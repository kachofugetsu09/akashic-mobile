import{c as r,s as e}from"./flowDiagram-23GEKE2U-CAW3aOsp.js";import{_ as a}from"./index-B3Q1lmTG.js";import"./chunk-5VM5RSS4-mDaH2jcZ.js";import"./chunk-XXDRQBXY-Bv5XeBcl.js";import"./chunk-VR4S4FIN-87_Ny8b-.js";import"./chunk-32BRIVSS-Go7Jcdtz.js";import"./channel-CVRKbWLI.js";import"./mobile-f0Mo13iw.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
