import{c as r,s as e}from"./flowDiagram-23GEKE2U-CAcTJxHx.js";import{_ as a}from"./mermaid-GHXKKRXX-DdvJiTtZ.js";import"./chunk-5VM5RSS4-BuIczYOa.js";import"./chunk-XXDRQBXY-Bcn8AZ0g.js";import"./chunk-VR4S4FIN-DN6ktPut.js";import"./chunk-32BRIVSS-DNDGyVbJ.js";import"./channel-Rctun1-d.js";import"./mobile-DwQhQ0O9.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
