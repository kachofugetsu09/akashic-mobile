import{c as r,s as e}from"./flowDiagram-23GEKE2U-CloaoV6f.js";import{_ as a}from"./index-VMEfhtX5.js";import"./chunk-5VM5RSS4-FX7NGlpe.js";import"./chunk-XXDRQBXY-BG_Hb9xi.js";import"./chunk-VR4S4FIN-7s9Mu78v.js";import"./chunk-32BRIVSS-Bej3o3Jp.js";import"./channel-CSHWnSJr.js";import"./mobile-VDX4LYXO.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
