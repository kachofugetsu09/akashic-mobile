import{ai as o,aj as n}from"./mermaid.core-qtDC1Um7.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
