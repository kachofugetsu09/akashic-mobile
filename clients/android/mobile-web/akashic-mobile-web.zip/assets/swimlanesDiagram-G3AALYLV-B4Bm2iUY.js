import{c as r,s as e}from"./flowDiagram-23GEKE2U-hu4npwXa.js";import{_ as a}from"./index-BaUlkUuD.js";import"./chunk-5VM5RSS4-DuXCuY9E.js";import"./chunk-XXDRQBXY-BYgSnnSW.js";import"./chunk-VR4S4FIN-HujZljrl.js";import"./chunk-32BRIVSS-CWviinUr.js";import"./channel-B0RJ3EOW.js";import"./mobile-CbVIMiFS.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
