import{c as r,s as e}from"./flowDiagram-23GEKE2U-DidyO4lx.js";import{_ as a}from"./index-BjN4z57t.js";import"./chunk-5VM5RSS4-CIIICiPg.js";import"./chunk-XXDRQBXY-BPPHjTUU.js";import"./chunk-VR4S4FIN-B2V7MnCz.js";import"./chunk-32BRIVSS-JL2fPAce.js";import"./channel-DIY8N7YZ.js";import"./mobile-CRupvtGD.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
