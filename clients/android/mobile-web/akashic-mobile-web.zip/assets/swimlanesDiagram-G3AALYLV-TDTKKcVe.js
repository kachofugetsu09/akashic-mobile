import{c as r,s as e}from"./flowDiagram-23GEKE2U-WsTe9Ez5.js";import{_ as a}from"./index-DOAhbcUm.js";import"./chunk-5VM5RSS4-D9w5uJ67.js";import"./chunk-XXDRQBXY-DpG-nMP6.js";import"./chunk-VR4S4FIN-BtGJE0q6.js";import"./chunk-32BRIVSS-CeSXewBQ.js";import"./channel-BR16C0pN.js";import"./mobile-D2-3xrTj.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
