import{c as r,s as e}from"./flowDiagram-23GEKE2U-_ZY8tmpr.js";import{_ as a}from"./mermaid-GHXKKRXX-D7Rtkq0K.js";import"./chunk-5VM5RSS4-DYIccZSi.js";import"./chunk-XXDRQBXY-Do7du5M-.js";import"./chunk-VR4S4FIN-DezTOIYz.js";import"./chunk-32BRIVSS-DfAuSykN.js";import"./channel-CrDJ2MK3.js";import"./mobile-DY4n377O.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
