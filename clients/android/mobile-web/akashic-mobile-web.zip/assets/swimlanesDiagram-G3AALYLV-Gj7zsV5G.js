import{c as r,s as e}from"./flowDiagram-23GEKE2U-Cf3PC23x.js";import{_ as a}from"./mermaid-GHXKKRXX-CkQEWesQ.js";import"./chunk-5VM5RSS4-CQIaOIPs.js";import"./chunk-XXDRQBXY-R6haCe6N.js";import"./chunk-VR4S4FIN-BeG4yXdx.js";import"./chunk-32BRIVSS-fIG3GAI8.js";import"./channel-DR-IAw6J.js";import"./mobile-CiEbp6WD.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
