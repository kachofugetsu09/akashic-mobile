import{U as a,C as n}from"./index-Do6lY4jL.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
