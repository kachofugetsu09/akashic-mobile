import{c as r,s as e}from"./flowDiagram-23GEKE2U-C57ZB86V.js";import{_ as a}from"./index-CbxtOlrq.js";import"./chunk-5VM5RSS4-DuzwkeiD.js";import"./chunk-XXDRQBXY-B31NigqG.js";import"./chunk-VR4S4FIN-DXGl64jk.js";import"./chunk-32BRIVSS-D_4NzHR-.js";import"./channel-DCi1LT-5.js";import"./mobile-C1NoQ9y8.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
