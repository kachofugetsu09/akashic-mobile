import{c as r,s as e}from"./flowDiagram-23GEKE2U-CJn6c_05.js";import{_ as a}from"./index-CynAsJAB.js";import"./chunk-5VM5RSS4-B30-M2Lb.js";import"./chunk-XXDRQBXY-BS8N6LQ-.js";import"./chunk-VR4S4FIN-C7RvLAKZ.js";import"./chunk-32BRIVSS-vrfGXoxa.js";import"./channel-DshnD9Dg.js";import"./mobile-kNrb1dxk.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
