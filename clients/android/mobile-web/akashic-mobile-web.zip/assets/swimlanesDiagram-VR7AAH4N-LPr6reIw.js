import{c as r,s as e}from"./flowDiagram-HODETNUW-D91tbz0u.js";import{_ as a}from"./mermaid.core-qtDC1Um7.js";import"./chunk-5VM5RSS4-Dhr80J6u.js";import"./chunk-XXDRQBXY-Cc32buaj.js";import"./chunk-POPQ4Y6H-BGNWx6at.js";import"./chunk-F27PBJKO-DsFQ_Pwl.js";import"./channel-B9pso76l.js";import"./mobile-DQBh2GT0.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
