import{c as r,s as e}from"./flowDiagram-HODETNUW-BpJWVkS8.js";import{_ as a}from"./mermaid.core-D84rVd-F.js";import"./chunk-5VM5RSS4-DqcxsIF0.js";import"./chunk-XXDRQBXY-DhIn4mZi.js";import"./chunk-POPQ4Y6H-LsYCtMZY.js";import"./chunk-F27PBJKO-B4HB0m92.js";import"./channel-CersmDMi.js";import"./mobile-B9f8VGWz.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
