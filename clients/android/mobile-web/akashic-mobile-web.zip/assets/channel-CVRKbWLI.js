import{U as a,C as n}from"./index-B3Q1lmTG.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
