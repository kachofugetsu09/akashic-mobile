import{c as r,s as e}from"./flowDiagram-23GEKE2U-GLOyD3Fh.js";import{_ as a}from"./index-DJ7tLJxp.js";import"./chunk-5VM5RSS4-DHi8F-Eq.js";import"./chunk-XXDRQBXY-D7pCV-R2.js";import"./chunk-VR4S4FIN-Dhocb198.js";import"./chunk-32BRIVSS-Dojh2bUw.js";import"./channel-Bl0Ky0cy.js";import"./mobile-DMJaGkX3.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
