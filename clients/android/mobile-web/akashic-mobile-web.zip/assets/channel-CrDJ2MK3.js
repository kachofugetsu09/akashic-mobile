import{U as a,C as n}from"./mermaid-GHXKKRXX-D7Rtkq0K.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
