import{c as r,s as e}from"./flowDiagram-23GEKE2U-Bb_yOXEA.js";import{_ as a}from"./index-MmM1u92o.js";import"./chunk-5VM5RSS4-DE7alMrr.js";import"./chunk-XXDRQBXY-CGF3IM4J.js";import"./chunk-VR4S4FIN-CQLQuPlh.js";import"./chunk-32BRIVSS-C5ErXG5H.js";import"./channel-BJaaSn0r.js";import"./mobile-BUNkBZxM.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
