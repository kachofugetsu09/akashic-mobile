import{c as r,s as e}from"./flowDiagram-23GEKE2U-FU52OJIQ.js";import{_ as a}from"./index-L9v9i1CL.js";import"./chunk-5VM5RSS4-BrYLUb1m.js";import"./chunk-XXDRQBXY-CJdlq10h.js";import"./chunk-VR4S4FIN-CDPQh2P3.js";import"./chunk-32BRIVSS-CSD373dH.js";import"./channel-Eyqi-r7m.js";import"./mobile-9rr2YMec.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
