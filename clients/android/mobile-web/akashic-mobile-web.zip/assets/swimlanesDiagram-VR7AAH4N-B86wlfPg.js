import{c as r,s as e}from"./flowDiagram-HODETNUW-BaiViRq9.js";import{_ as a}from"./mermaid.core-CEyiKDpf.js";import"./chunk-5VM5RSS4-BI1txVj-.js";import"./chunk-XXDRQBXY-CkW8Z0_M.js";import"./chunk-POPQ4Y6H-BQoaFXNh.js";import"./chunk-F27PBJKO-nmNUNKUn.js";import"./channel-eURn_aM8.js";import"./mobile-3BF8wbqS.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
