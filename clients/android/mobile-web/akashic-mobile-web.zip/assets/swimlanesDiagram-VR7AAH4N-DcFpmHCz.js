import{c as r,s as e}from"./flowDiagram-HODETNUW-DgI9z8Kw.js";import{_ as a}from"./mermaid.core-BMXQmL_r.js";import"./chunk-5VM5RSS4-B7WGehHt.js";import"./chunk-XXDRQBXY-DL_tNUjV.js";import"./chunk-POPQ4Y6H-CJ8SOLxW.js";import"./chunk-F27PBJKO-apW0KEQj.js";import"./channel-DYygyTzc.js";import"./mobile-DTcnQdeZ.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
