import{c as r,s as e}from"./flowDiagram-23GEKE2U-jst-IdMc.js";import{_ as a}from"./mermaid-GHXKKRXX-_q0sfIMg.js";import"./chunk-5VM5RSS4-CCbx4PVC.js";import"./chunk-XXDRQBXY-CMN0mJsJ.js";import"./chunk-VR4S4FIN-CN_KHJVw.js";import"./chunk-32BRIVSS-DrJZQv08.js";import"./channel-Cfs29MHc.js";import"./mobile-BgwlJidO.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
