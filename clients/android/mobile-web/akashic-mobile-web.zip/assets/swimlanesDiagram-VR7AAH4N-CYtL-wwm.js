import{c as r,s as e}from"./flowDiagram-HODETNUW-Bjjzp51P.js";import{_ as a}from"./mermaid.core-DJ3iMR6P.js";import"./chunk-5VM5RSS4-DuN211dn.js";import"./chunk-XXDRQBXY-DX7gboDy.js";import"./chunk-POPQ4Y6H-BcJtBW8y.js";import"./chunk-F27PBJKO-CJRKgesw.js";import"./channel-BLu-2iyE.js";import"./mobile-tFXQLFTT.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
