import{c as r,s as e}from"./flowDiagram-23GEKE2U-ClRmbJi1.js";import{_ as a}from"./mermaid-GHXKKRXX-BLkaoU9g.js";import"./chunk-5VM5RSS4-CfOK_gHa.js";import"./chunk-XXDRQBXY-m3MKXZcW.js";import"./chunk-VR4S4FIN-BJDwyV6Z.js";import"./chunk-32BRIVSS-DAZv2uIP.js";import"./channel-Byyf7JRD.js";import"./mobile-CYZS9iAz.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
