import{c as r,s as e}from"./flowDiagram-HODETNUW-CFQT4gEE.js";import{_ as a}from"./mermaid.core-xUOoNK-7.js";import"./chunk-5VM5RSS4-CBKTIm4w.js";import"./chunk-XXDRQBXY--MnwEQec.js";import"./chunk-POPQ4Y6H-3EXVvSPc.js";import"./chunk-F27PBJKO-oQIXmfbC.js";import"./channel-SvdRbueF.js";import"./mobile-DDmI0G6g.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
