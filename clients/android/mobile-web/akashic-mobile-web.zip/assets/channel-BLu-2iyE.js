import{ai as o,aj as n}from"./mermaid.core-DJ3iMR6P.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
