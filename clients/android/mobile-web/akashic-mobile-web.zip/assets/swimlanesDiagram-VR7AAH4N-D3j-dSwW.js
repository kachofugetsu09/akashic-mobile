import{c as r,s as e}from"./flowDiagram-HODETNUW-SaNUJEit.js";import{_ as a}from"./mermaid.core-DQQOfG4g.js";import"./chunk-5VM5RSS4-Cy9zQfCf.js";import"./chunk-XXDRQBXY-C0ytXhSU.js";import"./chunk-POPQ4Y6H-Bv77E2hg.js";import"./chunk-F27PBJKO-CubrrKrA.js";import"./channel-BYIZ8K2A.js";import"./mobile-WU7olwJf.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
