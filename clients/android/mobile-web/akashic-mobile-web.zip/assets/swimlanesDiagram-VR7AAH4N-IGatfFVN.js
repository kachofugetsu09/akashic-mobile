import{c as r,s as e}from"./flowDiagram-HODETNUW-DSeU1cZt.js";import{_ as a}from"./mermaid.core-C1kXLeLz.js";import"./chunk-5VM5RSS4-CBSnygGe.js";import"./chunk-XXDRQBXY-DWkPioNC.js";import"./chunk-POPQ4Y6H-BvKfCQFS.js";import"./chunk-F27PBJKO-DQaUxQR8.js";import"./channel-Di1mU5Vg.js";import"./mobile-Bx8Mn0ao.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
