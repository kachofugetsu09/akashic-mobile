import{c as r,s as e}from"./flowDiagram-23GEKE2U-BwDcGbX3.js";import{_ as a}from"./index-kxW_dWZL.js";import"./chunk-5VM5RSS4-DAuovZzc.js";import"./chunk-XXDRQBXY-DwIs6efu.js";import"./chunk-VR4S4FIN-BD37JDhF.js";import"./chunk-32BRIVSS-VScRM5pD.js";import"./channel-BFUnGQgL.js";import"./mobile-Dy786Bzk.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
